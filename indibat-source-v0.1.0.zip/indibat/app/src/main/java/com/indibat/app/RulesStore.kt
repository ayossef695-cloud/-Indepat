package com.indibat.app

import android.content.Context

/** Local prototype storage. Rules are stored on-device and are not uploaded. */
object RulesStore {
    private const val PREFS = "indibat_rules"
    private const val KEY_BLOCKED = "blocked_packages"
    private const val KEY_LIMITS = "daily_limits_minutes"
    private const val KEY_DAILY_CAP = "daily_cap_minutes"
    private const val KEY_TASK_PACKAGES = "task_allowed_packages"
    private const val KEY_TASK_ACTIVE = "task_active"

    fun blocked(context: Context): Set<String> = prefs(context).getStringSet(KEY_BLOCKED, emptySet())?.toSet() ?: emptySet()
    fun setBlocked(context: Context, values: Set<String>) { prefs(context).edit().putStringSet(KEY_BLOCKED, values).apply() }

    fun limits(context: Context): Map<String, Int> {
        val raw = prefs(context).getString(KEY_LIMITS, "") ?: ""
        if (raw.isBlank()) return emptyMap()
        return raw.split(";").mapNotNull { item ->
            val p = item.split("=")
            if (p.size == 2) p[0] to (p[1].toIntOrNull() ?: return@mapNotNull null) else null
        }.toMap()
    }

    fun setLimit(context: Context, packageName: String, minutes: Int) {
        val map = limits(context).toMutableMap(); map[packageName] = minutes
        prefs(context).edit().putString(KEY_LIMITS, map.entries.joinToString(";") { "${it.key}=${it.value}" }).apply()
    }

    fun dailyCap(context: Context): Int = prefs(context).getInt(KEY_DAILY_CAP, 180)
    fun setDailyCap(context: Context, minutes: Int) { prefs(context).edit().putInt(KEY_DAILY_CAP, minutes).apply() }

    fun taskAllowedPackages(context: Context): Set<String> = prefs(context).getStringSet(KEY_TASK_PACKAGES, emptySet())?.toSet() ?: emptySet()
    fun setTaskAllowedPackages(context: Context, values: Set<String>) { prefs(context).edit().putStringSet(KEY_TASK_PACKAGES, values).apply() }
    fun taskActive(context: Context): Boolean = prefs(context).getBoolean(KEY_TASK_ACTIVE, false)
    fun setTaskActive(context: Context, active: Boolean) { prefs(context).edit().putBoolean(KEY_TASK_ACTIVE, active).apply() }

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}
