package com.indibat.app

import android.app.Activity
import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private fun label(text: String, size: Float = 18f) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(0xFF17211D.toInt());
        setPadding(8, 14, 8, 14); gravity = Gravity.RIGHT
    }
    private fun button(text: String, action: () -> Unit) = Button(this).apply { this.text = text; setOnClickListener { action() } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; layoutDirection = ViewGroup.LAYOUT_DIRECTION_RTL
            setPadding(24, 28, 24, 24); setBackgroundColor(0xFFF7F9F8.toInt())
        }
        root.addView(label("انضباط", 30f))
        root.addView(label("تحكم في وقتك، وخصص الهاتف لما تريد إنجازه."))
        root.addView(label("حالة الصلاحيات", 20f))
        root.addView(label("إمكانية الوصول: فعّل خدمة «حماية انضباط» حتى يستطيع التطبيق اكتشاف التطبيق المفتوح." , 15f))
        root.addView(button("فتح إعدادات إمكانية الوصول") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        root.addView(label("إحصاءات الاستخدام: مطلوبة لحساب الوقت اليومي وحدود التطبيقات.", 15f))
        root.addView(button("فتح صلاحية الوصول إلى بيانات الاستخدام") { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) })
        root.addView(label("الإعدادات الأولية", 20f))
        root.addView(label("الحد اليومي الافتراضي: ${RulesStore.dailyCap(this)} دقيقة"))
        root.addView(button("تحديد الحد اليومي (ساعتان / 3 ساعات / 4 ساعات)") {
            val options = arrayOf("ساعتان", "3 ساعات", "4 ساعات")
            android.app.AlertDialog.Builder(this).setTitle("الحد اليومي")
                .setItems(options) { _, which -> RulesStore.setDailyCap(this, listOf(120,180,240)[which]); recreate() }.show()
        })
        root.addView(label("هذه نسخة تأسيسية: إدارة القوائم والمهام ومراقبة الوقت ستُستكمل في الإصدارات التالية.", 14f))
        setContentView(root)
    }

    @Suppress("unused")
    private fun hasUsageAccess(): Boolean {
        val ops = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        return ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
    }
}
