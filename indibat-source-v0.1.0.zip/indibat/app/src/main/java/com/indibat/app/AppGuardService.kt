package com.indibat.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

/** First-stage foreground-app detector. Blocking UI and robust timers are intentionally not enabled yet. */
class AppGuardService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            event?.eventType != AccessibilityEvent.TYPE_WINDOWS_CHANGED) return
        val foregroundPackage = event.packageName?.toString() ?: return
        if (foregroundPackage == packageName) return
        // Prototype hook: package policy evaluation will be connected to a blocking screen in the next build.
        // No app is forcibly closed in this starter build.
        RulesStore.blocked(this).contains(foregroundPackage)
    }
    override fun onInterrupt() = Unit
}
